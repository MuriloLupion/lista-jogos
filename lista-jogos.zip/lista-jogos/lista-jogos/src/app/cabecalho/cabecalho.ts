import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecalho',
  imports: [],
  templateUrl: './cabecalho.html',
  styleUrl: './cabecalho.css'
})
export class Cabecalho {

  titulo = 'lista-jogos';
  descricao = 'Uma lista dos jogos que já joguei e dos que quero jogar.';

}
