import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-galeria',
  imports: [FormsModule],
  templateUrl: './galeria.html',
  styleUrl: './galeria.css'
})
export class Galeria {

  nomeBusca = '';
  nomeJogo = '';
  generoJogo = '';
  mensagem = '';
  proximoId = 7;

  jogos = [
    { id: 1, nome: 'Minecraft', genero: 'Sobrevivência', nota: 9, jogado: true },
    { id: 2, nome: 'Stardew Valley', genero: 'Simulação', nota: 10, jogado: true },
    { id: 3, nome: 'Hollow Knight', genero: 'Aventura', nota: 9, jogado: true },
    { id: 4, nome: 'Terraria', genero: 'Sobrevivência', nota: 8, jogado: true },
    { id: 5, nome: 'Celeste', genero: 'Plataforma', nota: 0, jogado: false },
    { id: 6, nome: 'Undertale', genero: 'RPG', nota: 0, jogado: false }
  ];

  //buscar jogo pelo nome
  buscarJogos(){
    const nome = this.nomeBusca.trim().toLowerCase();
    return this.jogos.filter(jogo => jogo.nome.toLowerCase().includes(nome));
  }

  calcularTotalJogados(): number{
    let total = 0;

    for(const jogo of this.jogos){
      if(jogo.jogado){
        total++;
      }
    }

    return total;
  }

  //adicionar jogo na lista
  adicionarJogo(): void{
    if(this.nomeJogo.trim() === '' || this.generoJogo.trim() === ''){
      return;
    }

    for(const jogo of this.jogos){
      if(jogo.nome.toLowerCase() === this.nomeJogo.trim().toLowerCase()){
        this.mensagem = 'Esse jogo já está na lista.';
        return;
      }
    }

    this.jogos.push({
      id: this.proximoId,
      nome: this.nomeJogo.trim(),
      genero: this.generoJogo.trim(),
      nota: 0,
      jogado: false
    });

    this.proximoId++;
    this.nomeJogo = '';
    this.generoJogo = '';
    this.nomeBusca = '';
    this.mensagem = 'Jogo adicionado!';
  }

  //alterar se o jogo já foi jogado
  alterarStatus(idJogo: number): void{
    for(const jogo of this.jogos){
      if(jogo.id === idJogo){
        jogo.jogado = !jogo.jogado;

        if(!jogo.jogado){
          jogo.nota = 0;
        }
        return;
      }
    }
  }
}
