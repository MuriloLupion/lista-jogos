import { Component } from '@angular/core';
import { Cabecalho } from './cabecalho/cabecalho';
import { Galeria } from './galeria/galeria';

@Component({
  selector: 'app-root',
  imports: [Cabecalho, Galeria],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {}
