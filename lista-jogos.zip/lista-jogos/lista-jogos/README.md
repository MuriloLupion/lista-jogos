# lista-jogos

Trabalho do 1º bimestre de Desenvolvimento FrontEnd - UNIPAR.
Professor: Paulo H. P. Santos.
Tema escolhido: galeria de jogos (opção 2.4).

A aplicação organiza jogos que já foram jogados e jogos que ainda quero conhecer. É possível buscar pelo título, adicionar um jogo, mudar seu status e avaliar os jogos já jogados. Os títulos e as notas iniciais são exemplos e podem ser alterados no array `jogos`.

## Como executar no VS Code

1. Instale o Node.js 22.12 ou superior da linha 22, ou Node.js 24 LTS, com npm.
2. Extraia o ZIP. Não execute os comandos dentro do arquivo compactado.
3. No VS Code, abra a pasta `lista-jogos`, que contém o `package.json`.
4. Abra Terminal > Novo Terminal. No Windows, pode usar o Prompt de Comando.
5. Instale as dependências e inicie o projeto:

```bash
npm ci
npm start
```

6. Abra `http://localhost:4200` no navegador.
7. Para encerrar o servidor, pressione Ctrl + C no terminal.

`npm start` executa `ng serve`. Não é necessário instalar o Angular CLI globalmente. A primeira instalação precisa de internet. A pasta `node_modules` não está no ZIP porque é criada pelo npm.

## Criação do projeto

O projeto foi criado com Angular CLI 20, sem roteamento e sem SSR, usando:

```bash
npx --yes @angular/cli@20 new lista-jogos --standalone --routing=false --ssr=false --style=css --skip-git --skip-tests --package-manager=npm --defaults
```

A opção `--skip-tests` evita os arquivos de teste gerados automaticamente. Depois da criação, foram acrescentados os componentes Cabecalho e Galeria. Nesta versão do CLI, os nomes padrão são `app.ts` e `app.html`, em vez de `app.component.ts` e `app.component.html`.

## Organização dos arquivos

| Arquivo ou pasta | Para que serve |
| --- | --- |
| `src/main.ts` | Inicializa a aplicação com o componente principal e suas configurações. |
| `src/index.html` | Página que recebe o componente `app-root`. Define também título e idioma. |
| `src/styles.css` | Estilos compartilhados, como fonte, fundo e foco dos campos. |
| `src/app/app.ts` | Componente principal. Importa Cabecalho e Galeria. |
| `src/app/app.html` | Organiza o cabeçalho e a galeria dentro da página. |
| `src/app/app.css` | Define o fundo, o espaçamento e a fonte da página. |
| `src/app/app.config.ts` | Configuração de inicialização e detecção de alterações do Angular. |
| `src/app/cabecalho/cabecalho.ts` | Guarda o título e a descrição do cabeçalho. |
| `src/app/cabecalho/cabecalho.html` | Exibe as informações do cabeçalho. |
| `src/app/cabecalho/cabecalho.css` | Estiliza o cabeçalho. |
| `src/app/galeria/galeria.ts` | Contém o array, a busca, o cadastro e a alteração de status. |
| `src/app/galeria/galeria.html` | Formulário, resumo, busca e cards dos jogos. |
| `src/app/galeria/galeria.css` | Estilos da galeria e adaptação a telas menores. |
| `public/favicon.ico` | Ícone padrão exibido na aba do navegador. |
| `angular.json` | Configura os comandos de compilação e o servidor de desenvolvimento. |
| `package.json` | Lista as dependências e os comandos npm. |
| `package-lock.json` | Registra as versões instaladas para reproduzir a instalação. |
| `tsconfig.json` | Configurações gerais do TypeScript. |
| `tsconfig.app.json` | Configurações do TypeScript usadas na aplicação. |
| `tsconfig.spec.json` | Configuração reservada aos testes, gerada pelo CLI. |
| `.editorconfig` | Padroniza indentação e outros detalhes de edição. |
| `.gitignore` | Define arquivos que não devem entrar no Git. |
| `.vscode/extensions.json` | Sugere extensões para o VS Code. |
| `.vscode/launch.json` | Configurações de depuração no VS Code. |
| `.vscode/tasks.json` | Tarefas para executar comandos pelo editor. |

## Onde estão os requisitos

| Requisito | Exemplo no projeto |
| --- | --- |
| Dois componentes além do principal | Cabecalho e Galeria, importados em `app.ts`. |
| Interpolação de pelo menos três dados | `{{ jogo.nome }}`, `{{ jogo.genero }}` e `{{ jogo.nota }}`. |
| Property binding | `[disabled]` no botão Adicionar e `[class.resultado-pendente]` nos cards. |
| Event binding | `(click)="alterarStatus(jogo.id)"` e `(ngSubmit)="adicionarJogo()"`. |
| Two-way binding | `[(ngModel)]="nomeBusca"`, campos de cadastro e nota. `FormsModule` está importado na Galeria. |
| Condicional | `@if (jogo.jogado)` mostra a avaliação ou a mensagem de jogo pendente. |
| Repetição de pelo menos cinco itens | `@for` percorre `buscarJogos()`, calculado a partir do array `jogos`, que começa com seis itens. |
| CSS | Estilos globais e próprios de cada componente, incluindo adaptação para celular. |
| Sem routing e SSR | A aplicação tem uma única tela e é executada no navegador. |

## Entendendo a lógica

O array `jogos` fica dentro da classe Galeria. Cada item tem id, nome, gênero, nota e status. O TypeScript identifica os tipos a partir dos valores preenchidos.

`buscarJogos()` usa `filter` para devolver apenas os títulos que contêm o texto da busca. `toLowerCase` permite buscar sem diferenciar letras maiúsculas e minúsculas. Quando a busca está vazia, todos os jogos aparecem.

`adicionarJogo` verifica se título e gênero foram preenchidos. Também percorre a lista com `for` para verificar se o nome já está cadastrado. Se estiver tudo certo, `push` adiciona o novo jogo ao array, os campos são limpos e a busca é apagada para mostrar o item.

`alterarStatus` recebe o id do jogo, procura esse item com `for` e inverte o valor de `jogado`. Ao voltar um jogo para “Quero jogar”, sua nota é zerada. A barra de avaliação só aparece para jogos marcados como jogados e permite escolher números inteiros de 0 a 10. Zero é uma nota válida.

No `@for`, `track jogo.id` identifica cada jogo pelo seu código. Isso ajuda o Angular a acompanhar os itens da lista quando ela muda.

## Limites do projeto

Os dados ficam apenas na memória enquanto a página está aberta. Recarregar restaura os seis exemplos. Não há banco de dados, login, API nem salvamento no navegador. Essa escolha mantém o trabalho focado nos requisitos do enunciado.

## Conferência manual

- Ao abrir: conferir os seis cards, quatro jogos jogados e dois pendentes.
- Buscar “mine”: deve aparecer apenas Minecraft.
- Buscar um título inexistente: deve aparecer a mensagem de lista vazia.
- Limpar a busca: os seis cards voltam.
- Deixar título ou gênero vazio: o botão Adicionar fica desabilitado.
- Cadastrar um novo jogo: o card aparece como “Quero jogar” e o total aumenta.
- Cadastrar o mesmo título novamente: aparece o aviso de jogo repetido.
- Marcar Celeste como jogado: a avaliação aparece e os totais mudam.
- Alterar a nota: o número exibido acompanha a barra.
- Voltar para não jogado: a avaliação desaparece e a nota volta a zero.
- Reduzir a janela: os cards se reorganizam em duas ou uma coluna.

Para compilar a versão de produção:

```bash
npm run build
```

## Roteiro para explicar em sala

Comece mostrando o que a aplicação faz. Busque um título, cadastre outro jogo e altere o status e a nota de um card.

Depois, abra `app.ts` para mostrar os dois componentes importados. No cabeçalho, mostre como o título sai da classe e aparece no HTML pela interpolação.

Na Galeria, mostre o array de seis jogos. Abra o HTML e localize o `@for`, explicando que ele repete um card para cada item. Em seguida, mostre o `@if`, que decide se a avaliação aparece.

Use o campo de busca para explicar o `ngModel`: o texto digitado atualiza a variável `nomeBusca`, e o filtro usa essa variável. Mostre também a importação de `FormsModule`.

Por último, mostre o `[disabled]` e o `(click)`. O primeiro controla se o botão pode ser usado; o segundo chama um método quando o usuário clica.

Antes de entregar, revise os exemplos, pratique os métodos e confira como o professor quer receber a identificação da dupla.

## Referências de consulta

- Enunciado: Trabalho - 1º Bimestre, Desenvolvimento FrontEnd, UNIPAR, setembro de 2026.
- Angular: https://angular.dev/tools/cli/setup-local
- Angular, two-way binding: https://angular.dev/guide/templates/two-way-binding

## Verificação desta entrega

A compilação de produção (`npm run build`) terminou sem erros. Foram verificadas separadamente as regras de busca, campos vazios, cadastro, títulos repetidos, contadores e alteração de status com limpeza da nota. A conferência visual e de console no navegador não foi concluída no ambiente de preparação; use o roteiro manual acima ao executar no seu computador.
